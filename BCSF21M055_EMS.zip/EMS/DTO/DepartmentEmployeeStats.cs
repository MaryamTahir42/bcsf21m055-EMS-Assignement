﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO
{
    public class DepartmentEmployeeStats
    {
        public int DepartmentID { get; set; }
        public string DepartmentName { get; set; }
        public int Budget { get; set; }
        public int EmployeeCount { get; set; }
        public int TotalSalary { get; set; }
    }
}
