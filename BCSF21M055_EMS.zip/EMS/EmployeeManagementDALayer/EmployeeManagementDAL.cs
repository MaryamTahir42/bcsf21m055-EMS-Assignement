﻿using DTO;
using System;
using System.Collections.Generic;
using Dapper;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeManagementDALayer
{
    public class EmployeeManagementDAL : IEmployeeManagementDAL
    {
        private readonly string _connectionString;

        public EmployeeManagementDAL()
        {
            _connectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;Initial Catalog=EmployeeDB;Integrated Security=True;";
        }

        public IEnumerable<Employee> SearchEmployees(string information)
        {
            using (SqlConnection connection=new SqlConnection(_connectionString))
            {
                connection.Open();
                var query = @"Select * from Employee e inner join Department d on e.DepartmentID = d.DepartmentID
                              where d.DepartmentName=@information
                              or e.Position=@information
                              or e.FirstName=@information
                              or e.LastName=@information
                              or (e.FirstName + ' ' + e.LastName) = @information";

                var employees = connection.Query<Employee>(query, new { information });

                return employees;
            }
        }
        public Employee GetEmployeeById(int employeeId)
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                var query = "select * from Employee e where e.EmployeeID = @EmployeeID";
                var employee = connection.QuerySingleOrDefault<Employee>(query, new { EmployeeID = employeeId });
                return employee;
            }
        }
        public Department GetDepartmentById(int departmentId)
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                var query = "select * from Department d where d.DepartmentID = @DepartmentID";

                var department = connection.QuerySingleOrDefault<Department>(query, new { DepartmentID = departmentId });
                return department;
            }
        }

        public void AddEmployee(Employee employee)
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                string query = "Insert into Employee values(@FirstName, @LastName, @Position, @Salary, @DepartmentID)";
                connection.Execute(query, employee);
            }
        }

        
        public void UpdateEmployee(Employee employee)
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                string query = "Update Employee set FirstName = @FirstName, LastName = @LastName, Position = @Position, Salary = @Salary, DepartmentID = @DepartmentID where EmployeeId = @EmployeeId";
                connection.Execute(query, employee);
            }
        }

        public void DeleteEmployee(int employeeId)
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                string query = "Delete From Employee where EmployeeId = @EmployeeId";
                connection.Execute(query, new { EmployeeId =employeeId });
            }
        }

        public IEnumerable<Employee> GetAllEmployees()
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                string query = "Select * from Employee";

                return connection.Query<Employee>(query).ToList();
            }
        }
        public IEnumerable<Department> GetAllDepartments()
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                string query = " select * from Department";
                return connection.Query<Department>(query).ToList();
            }
        }

        public IEnumerable<DepartmentDetails> GetAllEmployeesDetails()
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                string query = @" select e.EmployeeID, e.FirstName, e.LastName, e.Position, e.Salary, e.DepartmentID, d.DepartmentName, d.Budget
                                 from Employee e join Department d on e.DepartmentID = d.DepartmentID";

                return connection.Query<DepartmentDetails>(query).ToList();
            }
        }
        public IEnumerable<DepartmentEmployeeStats> GetDepartmentWiseStats()
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                string query = @" select d.DepartmentID, d.DepartmentName, count(e.EmployeeID) as EmployeeCount, SUM(e.Salary) AS TotalSalary
                                from Department d join Employee e on d.DepartmentID = e.DepartmentID
                               group by d.DepartmentID, d.DepartmentName";

                return connection.Query<DepartmentEmployeeStats>(query).ToList();
            }
        }
        public int GetDepartmentBudget(int departmentId)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                var query = "select Budget from Department where DepartmentID = @DepartmentID";
                int budget = connection.ExecuteScalar<int>(query, new { DepartmentID = departmentId });
                return budget;
            }
        }
        public int GetTotalSalaryByDepartment(int departmentId)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();

                var query = " select sum(Salary) from Employee where DepartmentID = @DepartmentID";
                //? is for nullable thingys
                var totalSalary = connection.QuerySingleOrDefault<int?>(query, new { DepartmentID = departmentId }) ?? 0;
                return totalSalary;
            }
        }

        public IEnumerable<DepartmentEmployeeStats> GetDepartmentsWithTotalEmployees()
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();

                var query = @" select d.DepartmentID, d.DepartmentName,d.Budget, count(e.EmployeeID) as TotalEmployees,
                            sum(e.salary) as TotalSalary from
                                Department d left join Employee e on e.DepartmentID=d.DepartmentID
                                 group by d.DepartmentID,d.DepartmentName, d.Budget";

                var Departments = connection.Query<DepartmentEmployeeStats>(query);
                return Departments;
            }
        }
        public void UpdateDepartment(Department department)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                var query = "update Department set Budget = @Budget where DepartmentID = @DepartmentID";

                connection.Execute(query, new { Budget = department.Budget, DepartmentID = department.DepartmentID });
            }
        }

    }
}
