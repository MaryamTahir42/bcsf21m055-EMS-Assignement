﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DTO;

namespace EmployeeManagementDALayer
{
    public interface IEmployeeManagementDAL
    {
        IEnumerable<Employee> GetAllEmployees();               // Retrieve all employees with department details
        IEnumerable<Department> GetAllDepartments();
        Employee GetEmployeeById(int employeeId);              // Retrieve a specific employee by ID
        Department GetDepartmentById(int departmentId);
        void AddEmployee(Employee employee);                   // Add a new employee
        void UpdateEmployee(Employee employee);               // Update existing employee details
        void DeleteEmployee(int employeeId);                   // Delete an employee by ID
        IEnumerable<DepartmentDetails> GetAllEmployeesDetails();
        int GetDepartmentBudget(int departmentId);
        int GetTotalSalaryByDepartment(int departmentId);
        //void SelectiveUpdate(Employee employee);
        IEnumerable<Employee> SearchEmployees(string information);
        IEnumerable<DepartmentEmployeeStats> GetDepartmentsWithTotalEmployees();
        void UpdateDepartment(Department department);
    }
}
