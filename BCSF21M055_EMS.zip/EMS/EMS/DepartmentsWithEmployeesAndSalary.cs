﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using EmployeeManagementBLLayer;

namespace EMS
{
    public partial class DepartmentsWithEmployeesAndSalary : Form
    {
        private readonly IEmployeeManagementBLL _EMBLL;
        public DepartmentsWithEmployeesAndSalary(IEmployeeManagementBLL EMBLL)
        {
            InitializeComponent();
            _EMBLL = EMBLL;
        }

        private void DepartmentsWithEmployeesAndSalary_Load(object sender, EventArgs e)
        {
            var employees=_EMBLL.GetDepartmentsWithTotalEmployees();
            dataGridView1.DataSource = employees;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
