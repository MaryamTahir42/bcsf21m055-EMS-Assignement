﻿using EmployeeManagementBLLayer;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using EmployeeManagementBLLayer;
using DTO;

namespace EMS
{
    public partial class Search : Form
    {
        private readonly IEmployeeManagementBLL _EMBLL;
        public Search(IEmployeeManagementBLL EMBLL)
        {
            InitializeComponent();
            _EMBLL = EMBLL;

        }
        private void button1_Click(object sender, EventArgs e)
        {
            var employees=_EMBLL.SearchEmployees(textBox1.Text);
            if (employees == null)
                throw new Exception("No employees found");

            dataGridView1.DataSource = employees.ToList();
        }
        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Search_Load(object sender, EventArgs e)
        {

        }
    }
}
