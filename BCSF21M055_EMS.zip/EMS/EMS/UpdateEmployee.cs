﻿using DTO;
using EmployeeManagementBLLayer;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EMS
{
    public partial class UpdateEmployee : Form
    {
        private readonly IEmployeeManagementBLL _EMBLL;
        public UpdateEmployee(IEmployeeManagementBLL EMBLL)
        {
            InitializeComponent();
            _EMBLL = EMBLL;
        }

        //private void button1_Click(object sender, EventArgs e)
        //{
        //    int employeeId = Convert.ToInt32(textBox1.Text);
        //    int deptId = Convert.ToInt32(textBox5.Text);
        //    string newPosition = textBox3.Text;
        //    int newSalary = Convert.ToInt32(textBox4.Text);

        //    var employee = _EMBLL.GetEmployeeByID(employeeId);
        //    //this will get the department id of previous deparment of employee 
        //    // and im adding the salary of employee to this because she gone gurl
        //    var department=_EMBLL.GetDepartmentById(employee.DepartmentID);
        //    //we kept this so when a user say Maru has salary 250000 and the remaining 
        //    //budget of dept is 250000, we can give 500000 to Maru right?
        //    //so when i do that im updating dept 2's budget from 250000 to 250000+2500000=500000

        //    int extra = _EMBLL.GetDepartmentBudget(department.DepartmentID) + employee.Salary;
        //    //department.Budget=_EMBLL.GetDepartmentBudget(department.DepartmentID)+employee.Salary;
        //    try
        //    {

        //        //_EMBLL.UpdateDepartment(department);
        //        if (employee != null)
        //        {
        //            Employee newEmployee = new Employee();
        //            newEmployee.EmployeeID = employeeId;
        //            newEmployee.FirstName = employee.FirstName;
        //            newEmployee.LastName = employee.LastName;
        //            newEmployee.Position = newPosition;
        //            newEmployee.Salary = newSalary;
        //            newEmployee.DepartmentID = deptId;
        //            _EMBLL.SelectiveUpdate(newEmployee,extra);
        //            MessageBox.Show("Employee updated successfully!");
        //        }
        //        else
        //        {
        //            MessageBox.Show("Employee not found!");
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        MessageBox.Show(ex.Message);
        //    }

        //}

        private void button1_Click(object sender, EventArgs e)
        {
            int empId = Convert.ToInt32(textBox1.Text);
            var employee = _EMBLL.GetEmployeeByID(empId);
            var fName = employee.FirstName;
            var lName = employee.LastName ;
            var pos = textBox3.Text;
            int deptId = Convert.ToInt32(textBox5.Text);
            var sal = Convert.ToInt32(textBox4.Text);

            try
            {

                Employee emp = new Employee { EmployeeID = empId, FirstName = fName, DepartmentID = deptId, LastName = lName, Position = pos, Salary = sal };
                if (_EMBLL.UpdateEmployee(emp) == true)
                {
                    MessageBox.Show("Employee Updated Successfully.");
                }
                else
                {
                    MessageBox.Show("Could Not Update the Employee.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void UpdateEmployee_Load(object sender, EventArgs e)
        {

        }
    }
}
