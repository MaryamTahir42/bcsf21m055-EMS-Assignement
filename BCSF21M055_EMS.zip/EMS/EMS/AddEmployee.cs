﻿using DTO;
using EmployeeManagementBLLayer;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace EMS
{
    public partial class AddEmployee : Form
    {
        private readonly IEmployeeManagementBLL _EMBLL;
        public AddEmployee(IEmployeeManagementBLL EMBLL)
        {
            InitializeComponent();
            _EMBLL = EMBLL;
        }
        private void button1_Click(object sender, EventArgs e)
        {
            string firstName = textBox1.Text;
            string lastName = textBox2.Text;
            string position = textBox3.Text;
           
                int salary = Convert.ToInt32(textBox4.Text);
                int departmentID = Convert.ToInt32(textBox5.Text);
                Employee employee = new Employee { FirstName = firstName, DepartmentID= departmentID, LastName = lastName, Position = position, Salary = salary };

                bool x=_EMBLL.AddEmployee(employee);
                if(x)
                MessageBox.Show("Employee added successfully!");
                else
                MessageBox.Show("Employee could not be added!");



        }
        private void AddEmployee_Load(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

    }
}
