﻿using EmployeeManagementBLLayer;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EMS
{
    public partial class ListOfEmployees : Form
    {
        private readonly IEmployeeManagementBLL _EMBLL; 
        public ListOfEmployees(IEmployeeManagementBLL EMBLL)
        {
            _EMBLL = EMBLL;
            InitializeComponent();
        }

        private void ListOfEmployees_Load(object sender, EventArgs e)
        {
            var employees = _EMBLL.GetAllEmployeesDetails();
            dataGridView1.DataSource = employees;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
