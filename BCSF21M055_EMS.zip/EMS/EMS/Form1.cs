﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DTO;
using EmployeeManagementBLLayer;
using Microsoft.Extensions.DependencyInjection;

namespace EMS
{
    public partial class Form1 : Form
    {
        private IEmployeeManagementBLL _EMBLL;
        public Form1()
        {
            InitializeComponent();
            _EMBLL = Program.serviceProvider.GetRequiredService<IEmployeeManagementBLL>();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
           AddEmployee addEmployee = new AddEmployee(_EMBLL); 
            addEmployee.Show();
        }


        private void button4_Click(object sender, EventArgs e)
        {
            DeleteEmployee deleteEmployee= new DeleteEmployee(_EMBLL);
            deleteEmployee.Show();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            ListOfEmployees lisEmployees = new ListOfEmployees(_EMBLL);
            lisEmployees.Show();

           
        }

        private void button3_Click(object sender, EventArgs e)
        {
            UpdateEmployee updateEmployee = new UpdateEmployee(_EMBLL);
            updateEmployee.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            DepartmentsWithEmployeesAndSalary DES=new DepartmentsWithEmployeesAndSalary(_EMBLL);
            DES.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Search search = new Search(_EMBLL);
            search.Show();
        }
    }
}
