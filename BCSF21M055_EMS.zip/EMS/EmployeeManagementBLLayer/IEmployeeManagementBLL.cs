﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DTO;
using EmployeeManagementDALayer;

namespace EmployeeManagementBLLayer
{
    public interface IEmployeeManagementBLL
    {
        bool AddEmployee(Employee employee);
        bool UpdateEmployee(Employee employee);
        void SelectiveUpdate(Employee employee, int extra);
        bool DeleteEmployee(int employeeId);
        IEnumerable<DepartmentDetails> GetAllEmployeesDetails();
        IEnumerable<Employee> GetAllEmployees();
        int GetTotalSalaryByDepartment(int departmentId);
        IEnumerable<Employee> SearchEmployees(string searchTerm);
        Employee GetEmployeeByID(int employeeId);
        Department GetDepartmentById(int departmentId);
        bool DepartmentExists(int departmentId);
        IEnumerable<DepartmentEmployeeStats> GetDepartmentsWithTotalEmployees();
        int GetDepartmentBudget(int departmentId);
        void UpdateDepartment(Department department);
    }
}
