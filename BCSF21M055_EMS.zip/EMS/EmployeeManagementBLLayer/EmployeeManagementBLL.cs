﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dapper;
using DTO; 
using EmployeeManagementDALayer;

namespace EmployeeManagementBLLayer
{
    public class EmployeeManagementBLL : IEmployeeManagementBLL
    {
        private IEmployeeManagementDAL _employeeManagementDAL;

        public EmployeeManagementBLL(IEmployeeManagementDAL employeeManagementDAL)
        {
            _employeeManagementDAL = employeeManagementDAL;
        }

        public bool AddEmployee(Employee e)
        {
            if (string.IsNullOrEmpty(e.FirstName) ||
                string.IsNullOrEmpty(e.LastName) ||
                string.IsNullOrEmpty(e.Position) )
            {
                return false;
            }
            Department department = _employeeManagementDAL.GetDepartmentById(e.DepartmentID);
            if (e.Salary < 0 || department == null)
                return false;

            int budget = department.Budget;
            int deptSalary = _employeeManagementDAL.GetTotalSalaryByDepartment(department.DepartmentID);
            deptSalary += e.Salary;
            if (budget< deptSalary)
                return false;
            _employeeManagementDAL.AddEmployee(e);
            return true;
        }

        public void SelectiveUpdate(Employee employee, int extra)
        {
            var existingEmployee = _employeeManagementDAL.GetEmployeeById(employee.EmployeeID);
            int savesal = existingEmployee.Salary; //250000
            Department d = _employeeManagementDAL.GetDepartmentById(employee.DepartmentID);
            if (d!=null && IsBudgetAvailable2(employee.DepartmentID, employee.Salary,extra))
            {
                _employeeManagementDAL.UpdateEmployee(employee);
                d.Budget = _employeeManagementDAL.GetDepartmentBudget(d.DepartmentID) +savesal - employee.Salary;
                _employeeManagementDAL.UpdateDepartment(d);
            }
            else
            {
                throw new Exception("Department budget exceeded.");
            }

           
        }
        public bool UpdateEmployee(Employee e)
        {
         
            if (_employeeManagementDAL.GetEmployeeById(e.EmployeeID) == null)
                return false;
            if (e.Salary < 0)
                return false;
            
            Department department = _employeeManagementDAL.GetDepartmentById(e.DepartmentID);
            if (department == null)
                return false;

            Employee employee = _employeeManagementDAL.GetEmployeeById(e.EmployeeID);
            int budget = department.Budget;
            int deptSalary = _employeeManagementDAL.GetTotalSalaryByDepartment(department.DepartmentID);
            deptSalary += e.Salary;
            if (employee.DepartmentID == e.DepartmentID)
            {
                deptSalary -= employee.Salary;
            }
            if (deptSalary > budget)
                return false;

            _employeeManagementDAL.UpdateEmployee(e);
            return true;
            //var existingEmployee = _employeeManagementDAL.GetEmployeeById(employee.EmployeeID);
            //if (existingEmployee == null)
            //{
            //    throw new Exception("Employee does not exist.");
            //}
            //if (existingEmployee.DepartmentID != employee.DepartmentID && !IsBudgetAvailable(employee.DepartmentID, employee.Salary))
            //{
            //    throw new Exception("Department budget exceeded.");
            //}

            //_employeeManagementDAL.UpdateEmployee(employee);
        }

        public bool DeleteEmployee(int employeeId)
        {
            if (_employeeManagementDAL.GetEmployeeById(employeeId) == null)
            {
                return false;
            }
            _employeeManagementDAL.DeleteEmployee(employeeId);
            return true;
        }

        public IEnumerable<DepartmentDetails> GetAllEmployeesDetails()
        {
            return _employeeManagementDAL.GetAllEmployeesDetails();
        }
        public IEnumerable<Employee> GetAllEmployees()
        {
            return _employeeManagementDAL.GetAllEmployees();
        }

        public int GetTotalSalaryByDepartment(int departmentId)
        {
            Department d = _employeeManagementDAL.GetDepartmentById(departmentId);
            if(d!=null)
            {
                int usedSalary=_employeeManagementDAL.GetTotalSalaryByDepartment(departmentId);
                return usedSalary;
            }
            throw new Exception("Department not found");
        }

        public IEnumerable<Employee> SearchEmployees(string searchTerm)
        {
            var allEmployees = _employeeManagementDAL.GetAllEmployees();

            if (string.IsNullOrWhiteSpace(searchTerm))
            {
                return allEmployees;
            }
            var employees = _employeeManagementDAL.SearchEmployees(searchTerm);
            if (employees != null)
                return employees;
            else
                throw new Exception("No employee was found with this information");
        }

        public Employee GetEmployeeByID(int id)
        {
            return _employeeManagementDAL.GetEmployeeById(id);
        }
        public Department GetDepartmentById(int departmentId)
        {
            return _employeeManagementDAL.GetDepartmentById(departmentId);
        }
        public bool DepartmentExists(int departmentId)
        {
            var department= _employeeManagementDAL.GetDepartmentById(departmentId);
            return department!=null;
        }

        private bool IsBudgetAvailable2(int departmentId, int salary, int extra)
        {
            //salary used by a dept is returned 300000 in our case for dept 1
            //int totalSalaries = GetTotalSalaryByDepartment(departmentId);
            int departmentBudget = _employeeManagementDAL.GetDepartmentBudget(departmentId) ; //500000
            return (salary) < departmentBudget;
        }
        private bool IsBudgetAvailable(int departmentId, int salary)
        {
            //salary used by a dept is returned 300000 in our case for dept 1
            //int totalSalaries = GetTotalSalaryByDepartment(departmentId);
            int departmentBudget = _employeeManagementDAL.GetDepartmentBudget(departmentId); //200000
            return ( salary) <= departmentBudget;
        }
        public IEnumerable<DepartmentEmployeeStats> GetDepartmentsWithTotalEmployees()
        {
            var departments = _employeeManagementDAL.GetDepartmentsWithTotalEmployees();
            if (departments != null)
                return departments;
            else
                throw new Exception("Departments not found");
        }
        public int GetDepartmentBudget(int departmentId)
        {
           if(GetDepartmentById(departmentId)!=null)
            {
                return _employeeManagementDAL.GetDepartmentBudget(departmentId);
            }
            throw new Exception("Department Not found");
        }
        public void UpdateDepartment(Department department)
        {
            _employeeManagementDAL.UpdateDepartment(department);
        }

    }
}
